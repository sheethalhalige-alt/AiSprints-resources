'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Field } from '@/components/ui/field';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';

interface Option {
  text: string;
  isCorrect: boolean;
  order: number;
}

export default function NewQuestionPage() {
  const router = useRouter();
  const [questionText, setQuestionText] = useState('');
  const [points, setPoints] = useState(1);
  const [optionCount, setOptionCount] = useState<4 | 6>(4);
  const [options, setOptions] = useState<Option[]>([
    { text: '', isCorrect: false, order: 1 },
    { text: '', isCorrect: false, order: 2 },
    { text: '', isCorrect: false, order: 3 },
    { text: '', isCorrect: false, order: 4 },
  ]);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleOptionCountChange = (count: 4 | 6) => {
    setOptionCount(count);
    if (count === 6 && options.length === 4) {
      setOptions([
        ...options,
        { text: '', isCorrect: false, order: 5 },
        { text: '', isCorrect: false, order: 6 },
      ]);
    } else if (count === 4 && options.length === 6) {
      setOptions(options.slice(0, 4));
    }
  };

  const handleOptionChange = (index: number, field: 'text' | 'isCorrect', value: string | boolean) => {
    const newOptions = [...options];
    if (field === 'isCorrect' && value === true) {
      // Only one option can be correct
      newOptions.forEach((opt, i) => {
        opt.isCorrect = i === index;
      });
    } else if (field === 'text') {
      newOptions[index].text = value as string;
    }
    setOptions(newOptions);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    // Validation
    if (questionText.length < 10 || questionText.length > 1000) {
      setError('Question text must be between 10 and 1000 characters');
      return;
    }

    if (options.some(opt => opt.text.trim() === '')) {
      setError('All options must have text');
      return;
    }

    if (!options.some(opt => opt.isCorrect)) {
      setError('Please select one correct answer');
      return;
    }

    setLoading(true);

    try {
      const response = await fetch('/api/questions/create', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          questionText,
          difficulty: 'medium', // Default value
          points,
          options,
        }),
      });

      const data = await response.json() as { message?: string };

      if (!response.ok) {
        setError(data.message || 'Failed to create question');
        setLoading(false);
        return;
      }

      router.push('/instructor/dashboard');
    } catch {
      setError('An error occurred. Please try again.');
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <nav className="bg-white shadow-sm border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex justify-between items-center">
            <h1 className="text-2xl font-bold text-gray-900">Create New Question</h1>
            <Link href="/instructor/dashboard">
              <Button variant="outline">Back to Dashboard</Button>
            </Link>
          </div>
        </div>
      </nav>

      <div className="container mx-auto px-4 py-8">
        <Card className="max-w-3xl mx-auto">
          <CardHeader>
            <CardTitle>New Question</CardTitle>
            <CardDescription>Create a multiple-choice question for your quiz</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              {error && (
                <div className="bg-red-50 text-red-600 p-3 rounded-md text-sm">
                  {error}
                </div>
              )}

              <Field>
                <Label htmlFor="questionText">Question Text *</Label>
                <Textarea
                  id="questionText"
                  value={questionText}
                  onChange={(e) => setQuestionText(e.target.value)}
                  required
                  minLength={10}
                  maxLength={1000}
                  rows={3}
                  placeholder="Enter your question here..."
                  className="resize-none"
                />
                <p className="text-xs text-gray-500 mt-1">
                  {questionText.length}/1000 characters (minimum 10)
                </p>
              </Field>

              <div className="grid grid-cols-2 gap-4">
                <Field>
                  <Label htmlFor="points">Points *</Label>
                  <input
                    id="points"
                    type="number"
                    value={points}
                    onChange={(e) => setPoints(parseInt(e.target.value))}
                    min={1}
                    required
                    className="w-full px-3 py-2 border border-gray-300 rounded-md"
                  />
                </Field>

                <Field>
                  <Label htmlFor="optionCount">Number of Options *</Label>
                  <select
                    id="optionCount"
                    value={optionCount}
                    onChange={(e) => handleOptionCountChange(parseInt(e.target.value) as 4 | 6)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md"
                  >
                    <option value={4}>4 Options</option>
                    <option value={6}>6 Options</option>
                  </select>
                </Field>
              </div>

              <div>
                <Label>Answer Options *</Label>
                <p className="text-sm text-gray-600 mb-3">
                  Enter all options and mark one as correct
                </p>
                <div className="space-y-3">
                  {options.map((option, index) => (
                    <div key={index} className="flex gap-3 items-start">
                      <input
                        type="radio"
                        name="correctAnswer"
                        checked={option.isCorrect}
                        onChange={() => handleOptionChange(index, 'isCorrect', true)}
                        className="mt-3"
                      />
                      <div className="flex-1">
                        <Label className="text-sm">Option {index + 1}</Label>
                        <input
                          type="text"
                          value={option.text}
                          onChange={(e) => handleOptionChange(index, 'text', e.target.value)}
                          required
                          className="w-full px-3 py-2 border border-gray-300 rounded-md"
                          placeholder={`Enter option ${index + 1}`}
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="flex gap-3">
                <Button type="submit" disabled={loading} className="flex-1">
                  {loading ? 'Creating...' : 'Create Question'}
                </Button>
                <Link href="/instructor/dashboard" className="flex-1">
                  <Button type="button" variant="outline" className="w-full">
                    Cancel
                  </Button>
                </Link>
              </div>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

