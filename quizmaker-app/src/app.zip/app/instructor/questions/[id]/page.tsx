'use client';

import { useState, useEffect, use } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';

interface Option {
  id: string;
  text: string;
  isCorrect: boolean;
  order: number;
}

interface Question {
  id: string;
  questionText: string;
  points: number;
  options: Option[];
  canEdit: boolean;
  createdAt: string;
  updatedAt: string;
}

interface Statistics {
  totalAttempts: number;
  correctAttempts: number;
  incorrectAttempts: number;
  successRate: number;
  averageTimeSeconds: number;
  optionDistribution: Array<{
    optionId: string;
    optionText: string;
    isCorrect: boolean;
    selectionCount: number;
    percentage: number;
  }>;
}

export default function ViewQuestionPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params);
  const router = useRouter();
  const [question, setQuestion] = useState<Question | null>(null);
  const [statistics, setStatistics] = useState<Statistics | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    fetchQuestion();
    fetchStatistics();
  }, [id]);

  const fetchQuestion = async () => {
    try {
      const response = await fetch(`/api/questions/${id}`);
      const data = await response.json();

      if (!response.ok) {
        setError(data.message || 'Failed to load question');
        setLoading(false);
        return;
      }

      setQuestion(data.question);
    } catch (err) {
      setError('An error occurred while loading the question');
    } finally {
      setLoading(false);
    }
  };

  const fetchStatistics = async () => {
    try {
      const response = await fetch(`/api/questions/${id}/statistics`);
      const data = await response.json();

      if (data.success) {
        setStatistics(data.statistics);
      }
    } catch (err) {
      // Statistics are optional, don't show error
      console.error('Failed to load statistics:', err);
    }
  };

  const handleDelete = async (force: boolean = false) => {
    const confirmMessage = force
      ? 'This question has student attempts. Deleting it will also remove all attempt history. Are you sure you want to proceed?'
      : 'Are you sure you want to delete this question? This action cannot be undone.';

    if (!confirm(confirmMessage)) {
      return;
    }

    try {
      const url = force ? `/api/questions/${id}?force=true` : `/api/questions/${id}`;
      const response = await fetch(url, { method: 'DELETE' });
      const data = await response.json();

      if (data.success) {
        router.push('/instructor/dashboard');
      } else if (response.status === 409 && data.message?.includes('attempts')) {
        // Question has attempts - offer force delete option
        if (confirm(`${data.message}\n\nWould you like to force delete this question and all its attempt history?`)) {
          handleDelete(true);
        }
      } else {
        alert(data.message || 'Failed to delete question');
      }
    } catch (err) {
      alert('An error occurred while deleting the question');
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
        <nav className="bg-white shadow-sm border-b border-slate-200">
          <div className="container mx-auto px-4 py-4">
            <div className="flex justify-between items-center">
              <h1 className="text-2xl font-bold text-slate-900">View Question</h1>
              <Link href="/instructor/dashboard">
                <Button variant="outline">Back to Dashboard</Button>
              </Link>
            </div>
          </div>
        </nav>
        <div className="container mx-auto px-4 py-12">
          <div className="flex items-center justify-center">
            <div className="animate-pulse flex flex-col items-center gap-4">
              <div className="w-16 h-16 rounded-full bg-slate-200"></div>
              <p className="text-slate-600">Loading question...</p>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (error || !question) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
        <nav className="bg-white shadow-sm border-b border-slate-200">
          <div className="container mx-auto px-4 py-4">
            <div className="flex justify-between items-center">
              <h1 className="text-2xl font-bold text-slate-900">View Question</h1>
              <Link href="/instructor/dashboard">
                <Button variant="outline">Back to Dashboard</Button>
              </Link>
            </div>
          </div>
        </nav>
        <div className="container mx-auto px-4 py-12">
          <Card className="max-w-2xl mx-auto border-red-200 bg-red-50">
            <CardContent className="text-center py-12">
              <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-red-100 flex items-center justify-center">
                <svg className="w-8 h-8 text-red-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
                </svg>
              </div>
              <h3 className="text-xl font-semibold text-red-800 mb-2">Error Loading Question</h3>
              <p className="text-red-600 mb-6">{error || 'Question not found'}</p>
              <Link href="/instructor/dashboard">
                <Button>Return to Dashboard</Button>
              </Link>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
      <nav className="bg-white shadow-sm border-b border-slate-200">
        <div className="container mx-auto px-4 py-4">
          <div className="flex justify-between items-center">
            <h1 className="text-2xl font-bold text-slate-900">View Question</h1>
            <Link href="/instructor/dashboard">
              <Button variant="outline">Back to Dashboard</Button>
            </Link>
          </div>
        </div>
      </nav>

      <div className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto space-y-6">
          {/* Question Details Card */}
          <Card className="border-slate-200 shadow-lg">
            <CardHeader className="border-b border-slate-100 bg-slate-50/50">
              <div className="flex justify-between items-start">
                <div>
                  <CardTitle className="text-xl text-slate-900">Question Details</CardTitle>
                  <CardDescription className="mt-1">
                    Created {formatDate(question.createdAt)}
                  </CardDescription>
                </div>
                <Badge className="bg-indigo-100 text-indigo-800 border-indigo-200">
                  {question.points} {question.points === 1 ? 'Point' : 'Points'}
                </Badge>
              </div>
            </CardHeader>
            <CardContent className="pt-6">
              {/* Question Text */}
              <div className="mb-6">
                <h3 className="text-sm font-medium text-slate-500 mb-2">Question</h3>
                <p className="text-lg text-slate-900 bg-slate-50 p-4 rounded-lg border border-slate-200">
                  {question.questionText}
                </p>
              </div>

              {/* Options */}
              <div>
                <h3 className="text-sm font-medium text-slate-500 mb-3">Answer Options</h3>
                <div className="space-y-3">
                  {question.options
                    .sort((a, b) => a.order - b.order)
                    .map((option, index) => (
                      <div
                        key={option.id}
                        className={`flex items-center gap-3 p-4 rounded-lg border-2 transition-colors ${
                          option.isCorrect
                            ? 'bg-emerald-50 border-emerald-300'
                            : 'bg-white border-slate-200'
                        }`}
                      >
                        <div
                          className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold ${
                            option.isCorrect
                              ? 'bg-emerald-500 text-white'
                              : 'bg-slate-200 text-slate-600'
                          }`}
                        >
                          {String.fromCharCode(65 + index)}
                        </div>
                        <span className={`flex-1 ${option.isCorrect ? 'font-medium text-emerald-900' : 'text-slate-700'}`}>
                          {option.text}
                        </span>
                        {option.isCorrect && (
                          <Badge className="bg-emerald-500 text-white border-0">
                            ✓ Correct Answer
                          </Badge>
                        )}
                      </div>
                    ))}
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Statistics Card */}
          {statistics && statistics.totalAttempts > 0 && (
            <Card className="border-slate-200 shadow-lg">
              <CardHeader className="border-b border-slate-100 bg-slate-50/50">
                <CardTitle className="text-xl text-slate-900">Question Statistics</CardTitle>
                <CardDescription>Performance data from student attempts</CardDescription>
              </CardHeader>
              <CardContent className="pt-6">
                {/* Summary Stats */}
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
                  <div className="bg-slate-50 p-4 rounded-lg text-center border border-slate-200">
                    <p className="text-2xl font-bold text-slate-900">{statistics.totalAttempts}</p>
                    <p className="text-sm text-slate-600">Total Attempts</p>
                  </div>
                  <div className="bg-emerald-50 p-4 rounded-lg text-center border border-emerald-200">
                    <p className="text-2xl font-bold text-emerald-700">{statistics.correctAttempts}</p>
                    <p className="text-sm text-emerald-600">Correct</p>
                  </div>
                  <div className="bg-rose-50 p-4 rounded-lg text-center border border-rose-200">
                    <p className="text-2xl font-bold text-rose-700">{statistics.incorrectAttempts}</p>
                    <p className="text-sm text-rose-600">Incorrect</p>
                  </div>
                  <div className="bg-indigo-50 p-4 rounded-lg text-center border border-indigo-200">
                    <p className="text-2xl font-bold text-indigo-700">{statistics.successRate.toFixed(1)}%</p>
                    <p className="text-sm text-indigo-600">Success Rate</p>
                  </div>
                </div>

                {/* Average Time */}
                {statistics.averageTimeSeconds > 0 && (
                  <div className="mb-6">
                    <p className="text-sm text-slate-600">
                      Average time to answer: <span className="font-medium text-slate-900">{statistics.averageTimeSeconds.toFixed(1)} seconds</span>
                    </p>
                  </div>
                )}

                {/* Option Distribution */}
                <div>
                  <h4 className="text-sm font-medium text-slate-700 mb-3">Answer Distribution</h4>
                  <div className="space-y-2">
                    {statistics.optionDistribution.map((dist, index) => (
                      <div key={dist.optionId} className="flex items-center gap-3">
                        <span className="w-6 text-sm font-medium text-slate-500">
                          {String.fromCharCode(65 + index)}
                        </span>
                        <div className="flex-1 h-6 bg-slate-100 rounded-full overflow-hidden">
                          <div
                            className={`h-full rounded-full transition-all ${
                              dist.isCorrect ? 'bg-emerald-500' : 'bg-slate-400'
                            }`}
                            style={{ width: `${dist.percentage}%` }}
                          />
                        </div>
                        <span className="w-16 text-sm text-slate-600 text-right">
                          {dist.selectionCount} ({dist.percentage.toFixed(0)}%)
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Action Buttons */}
          {question.canEdit && (
            <Card className="border-slate-200 shadow-lg">
              <CardContent className="py-4">
                <div className="flex gap-3 justify-end">
                  <Link href={`/instructor/questions/${id}/edit`}>
                    <Button className="bg-indigo-600 hover:bg-indigo-700">
                      <svg className="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
                      </svg>
                      Edit Question
                    </Button>
                  </Link>
                  <Button
                    variant="outline"
                    onClick={handleDelete}
                    className="text-red-600 border-red-300 hover:bg-red-50"
                  >
                    <svg className="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                    </svg>
                    Delete Question
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}

