'use client';

import { useState, useEffect, use } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Field } from '@/components/ui/field';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';

interface Option {
  id?: string;
  text: string;
  isCorrect: boolean;
  order: number;
}

interface Question {
  id: string;
  questionText: string;
  points: number;
  options: Array<{
    id: string;
    text: string;
    isCorrect: boolean;
    order: number;
  }>;
  canEdit: boolean;
}

export default function EditQuestionPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params);
  const router = useRouter();
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  // Form state
  const [questionText, setQuestionText] = useState('');
  const [points, setPoints] = useState(1);
  const [optionCount, setOptionCount] = useState<4 | 6>(4);
  const [options, setOptions] = useState<Option[]>([
    { text: '', isCorrect: false, order: 1 },
    { text: '', isCorrect: false, order: 2 },
    { text: '', isCorrect: false, order: 3 },
    { text: '', isCorrect: false, order: 4 },
  ]);

  useEffect(() => {
    fetchQuestion();
  }, [id]);

  const fetchQuestion = async () => {
    try {
      const response = await fetch(`/api/questions/${id}`);
      const data = await response.json();

      if (!response.ok) {
        setError(data.message || 'Failed to load question');
        setLoading(false);
        return;
      }

      if (!data.question.canEdit) {
        setError('You do not have permission to edit this question');
        setLoading(false);
        return;
      }

      const q: Question = data.question;
      setQuestionText(q.questionText);
      setPoints(q.points);

      // Set options
      const sortedOptions = q.options.sort((a, b) => a.order - b.order);
      setOptionCount(sortedOptions.length as 4 | 6);
      setOptions(
        sortedOptions.map((opt) => ({
          id: opt.id,
          text: opt.text,
          isCorrect: opt.isCorrect,
          order: opt.order,
        }))
      );
    } catch (err) {
      setError('An error occurred while loading the question');
    } finally {
      setLoading(false);
    }
  };

  const handleOptionCountChange = (count: 4 | 6) => {
    setOptionCount(count);
    if (count === 6 && options.length === 4) {
      setOptions([
        ...options,
        { text: '', isCorrect: false, order: 5 },
        { text: '', isCorrect: false, order: 6 },
      ]);
    } else if (count === 4 && options.length === 6) {
      // Make sure correct answer is not in last 2 options
      const correctInLast2 = options.slice(4).some((opt) => opt.isCorrect);
      if (correctInLast2) {
        setError('Cannot reduce options: correct answer is in options 5 or 6');
        return;
      }
      setOptions(options.slice(0, 4));
    }
  };

  const handleOptionChange = (index: number, field: 'text' | 'isCorrect', value: string | boolean) => {
    const newOptions = [...options];
    if (field === 'isCorrect' && value === true) {
      // Only one option can be correct
      newOptions.forEach((opt, i) => {
        opt.isCorrect = i === index;
      });
    } else if (field === 'text') {
      newOptions[index].text = value as string;
    }
    setOptions(newOptions);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccess('');

    // Validation
    if (questionText.length < 10 || questionText.length > 1000) {
      setError('Question text must be between 10 and 1000 characters');
      return;
    }

    if (options.some((opt) => opt.text.trim() === '')) {
      setError('All options must have text');
      return;
    }

    if (!options.some((opt) => opt.isCorrect)) {
      setError('Please select one correct answer');
      return;
    }

    setSaving(true);

    try {
      const response = await fetch(`/api/questions/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          questionText,
          points,
          options,
        }),
      });

      const data = await response.json();

      if (!response.ok) {
        setError(data.message || 'Failed to update question');
        setSaving(false);
        return;
      }

      setSuccess('Question updated successfully!');
      setTimeout(() => {
        router.push(`/instructor/questions/${id}`);
      }, 1500);
    } catch (err) {
      setError('An error occurred. Please try again.');
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
        <nav className="bg-white shadow-sm border-b border-slate-200">
          <div className="container mx-auto px-4 py-4">
            <div className="flex justify-between items-center">
              <h1 className="text-2xl font-bold text-slate-900">Edit Question</h1>
              <Link href="/instructor/dashboard">
                <Button variant="outline">Back to Dashboard</Button>
              </Link>
            </div>
          </div>
        </nav>
        <div className="container mx-auto px-4 py-12">
          <div className="flex items-center justify-center">
            <div className="animate-pulse flex flex-col items-center gap-4">
              <div className="w-16 h-16 rounded-full bg-slate-200"></div>
              <p className="text-slate-600">Loading question...</p>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (error && !questionText) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
        <nav className="bg-white shadow-sm border-b border-slate-200">
          <div className="container mx-auto px-4 py-4">
            <div className="flex justify-between items-center">
              <h1 className="text-2xl font-bold text-slate-900">Edit Question</h1>
              <Link href="/instructor/dashboard">
                <Button variant="outline">Back to Dashboard</Button>
              </Link>
            </div>
          </div>
        </nav>
        <div className="container mx-auto px-4 py-12">
          <Card className="max-w-2xl mx-auto border-red-200 bg-red-50">
            <CardContent className="text-center py-12">
              <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-red-100 flex items-center justify-center">
                <svg className="w-8 h-8 text-red-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
                </svg>
              </div>
              <h3 className="text-xl font-semibold text-red-800 mb-2">Cannot Edit Question</h3>
              <p className="text-red-600 mb-6">{error}</p>
              <Link href="/instructor/dashboard">
                <Button>Return to Dashboard</Button>
              </Link>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
      <nav className="bg-white shadow-sm border-b border-slate-200">
        <div className="container mx-auto px-4 py-4">
          <div className="flex justify-between items-center">
            <h1 className="text-2xl font-bold text-slate-900">Edit Question</h1>
            <div className="flex gap-2">
              <Link href={`/instructor/questions/${id}`}>
                <Button variant="outline">View Question</Button>
              </Link>
              <Link href="/instructor/dashboard">
                <Button variant="outline">Back to Dashboard</Button>
              </Link>
            </div>
          </div>
        </div>
      </nav>

      <div className="container mx-auto px-4 py-8">
        <Card className="max-w-3xl mx-auto border-slate-200 shadow-lg">
          <CardHeader className="border-b border-slate-100 bg-slate-50/50">
            <CardTitle className="text-xl text-slate-900">Edit Question</CardTitle>
            <CardDescription>Update your multiple-choice question details</CardDescription>
          </CardHeader>
          <CardContent className="pt-6">
            <form onSubmit={handleSubmit} className="space-y-6">
              {error && (
                <div className="bg-red-50 text-red-600 p-4 rounded-lg border border-red-200 text-sm flex items-center gap-2">
                  <svg className="w-5 h-5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                  {error}
                </div>
              )}

              {success && (
                <div className="bg-emerald-50 text-emerald-600 p-4 rounded-lg border border-emerald-200 text-sm flex items-center gap-2">
                  <svg className="w-5 h-5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                  {success}
                </div>
              )}

              <Field>
                <Label htmlFor="questionText">Question Text *</Label>
                <Textarea
                  id="questionText"
                  value={questionText}
                  onChange={(e) => setQuestionText(e.target.value)}
                  required
                  minLength={10}
                  maxLength={1000}
                  rows={3}
                  placeholder="Enter your question here..."
                  className="resize-none border-slate-300 focus:border-indigo-500 focus:ring-indigo-500"
                />
                <p className="text-xs text-slate-500 mt-1">
                  {questionText.length}/1000 characters (minimum 10)
                </p>
              </Field>

              <div className="grid grid-cols-2 gap-4">
                <Field>
                  <Label htmlFor="points">Points *</Label>
                  <input
                    id="points"
                    type="number"
                    value={points}
                    onChange={(e) => setPoints(parseInt(e.target.value))}
                    min={1}
                    required
                    className="w-full px-3 py-2 border border-slate-300 rounded-md focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 outline-none transition"
                  />
                </Field>

                <Field>
                  <Label htmlFor="optionCount">Number of Options *</Label>
                  <select
                    id="optionCount"
                    value={optionCount}
                    onChange={(e) => handleOptionCountChange(parseInt(e.target.value) as 4 | 6)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-md focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 outline-none transition"
                  >
                    <option value={4}>4 Options</option>
                    <option value={6}>6 Options</option>
                  </select>
                </Field>
              </div>

              <div>
                <Label>Answer Options *</Label>
                <p className="text-sm text-slate-600 mb-3">
                  Enter all options and mark one as correct
                </p>
                <div className="space-y-3">
                  {options.map((option, index) => (
                    <div key={index} className="flex gap-3 items-start">
                      <div className="pt-2">
                        <input
                          type="radio"
                          name="correctAnswer"
                          checked={option.isCorrect}
                          onChange={() => handleOptionChange(index, 'isCorrect', true)}
                          className="w-4 h-4 text-indigo-600 border-slate-300 focus:ring-indigo-500"
                        />
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <span className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold ${
                            option.isCorrect
                              ? 'bg-emerald-500 text-white'
                              : 'bg-slate-200 text-slate-600'
                          }`}>
                            {String.fromCharCode(65 + index)}
                          </span>
                          <Label className="text-sm mb-0">Option {index + 1}</Label>
                          {option.isCorrect && (
                            <span className="text-xs text-emerald-600 font-medium">(Correct Answer)</span>
                          )}
                        </div>
                        <input
                          type="text"
                          value={option.text}
                          onChange={(e) => handleOptionChange(index, 'text', e.target.value)}
                          required
                          className={`w-full px-3 py-2 border rounded-md transition outline-none ${
                            option.isCorrect
                              ? 'border-emerald-300 bg-emerald-50 focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500'
                              : 'border-slate-300 focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500'
                          }`}
                          placeholder={`Enter option ${index + 1}`}
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="flex gap-3 pt-4 border-t border-slate-200">
                <Button
                  type="submit"
                  disabled={saving}
                  className="flex-1 bg-indigo-600 hover:bg-indigo-700"
                >
                  {saving ? (
                    <>
                      <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" fill="none" viewBox="0 0 24 24">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                      </svg>
                      Saving Changes...
                    </>
                  ) : (
                    'Save Changes'
                  )}
                </Button>
                <Link href={`/instructor/questions/${id}`} className="flex-1">
                  <Button type="button" variant="outline" className="w-full">
                    Cancel
                  </Button>
                </Link>
              </div>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

