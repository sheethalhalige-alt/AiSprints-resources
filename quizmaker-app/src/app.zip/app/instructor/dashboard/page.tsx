'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';

interface Question {
  id: string;
  questionText: string;
  points: number;
  optionCount: number;
  createdAt: string;
}

export default function InstructorDashboard() {
  const router = useRouter();
  const [questions, setQuestions] = useState<Question[]>([]);
  const [loading, setLoading] = useState(true);
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [user, setUser] = useState<any>(null);

  useEffect(() => {
    fetchUser();
    fetchQuestions();
  }, [page]);

  const fetchUser = async () => {
    try {
      const response = await fetch('/api/auth/me');
      const data = await response.json();
      if (data.success) {
        setUser(data.user);
      }
    } catch (error) {
      console.error('Failed to fetch user:', error);
    }
  };

  const fetchQuestions = async () => {
    try {
      const response = await fetch(`/api/questions?page=${page}&limit=10`);
      const data = await response.json();
      
      if (data.success) {
        setQuestions(data.questions);
        setTotalPages(data.totalPages);
      }
    } catch (error) {
      console.error('Failed to fetch questions:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleLogout = async () => {
    await fetch('/api/auth/logout', { method: 'POST' });
    router.push('/login');
  };

  const handleDelete = async (id: string, force: boolean = false) => {
    const confirmMessage = force
      ? 'This question has student attempts. Deleting it will also remove all attempt history. Are you sure you want to proceed?'
      : 'Are you sure you want to delete this question?';

    if (!confirm(confirmMessage)) {
      return;
    }

    try {
      const url = force ? `/api/questions/${id}?force=true` : `/api/questions/${id}`;
      const response = await fetch(url, { method: 'DELETE' });
      const data = await response.json();

      if (data.success) {
        fetchQuestions();
      } else if (response.status === 409 && data.message?.includes('attempts')) {
        // Question has attempts - offer force delete option
        if (confirm(`${data.message}\n\nWould you like to force delete this question and all its attempt history?`)) {
          handleDelete(id, true);
        }
      } else {
        alert(data.message);
      }
    } catch (error) {
      alert('Failed to delete question');
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <nav className="bg-white shadow-sm border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex justify-between items-center">
            <h1 className="text-2xl font-bold text-gray-900">QuizMaker - Instructor</h1>
            <div className="flex items-center gap-4">
              <span className="text-sm text-gray-600">
                {user?.name} ({user?.email})
              </span>
              <Button variant="outline" onClick={handleLogout}>
                Logout
              </Button>
            </div>
          </div>
        </div>
      </nav>

      <div className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <div className="flex justify-between items-center mb-6">
            <div>
              <h2 className="text-3xl font-bold text-gray-900">My Questions</h2>
              <p className="text-gray-600 mt-1">Manage your quiz questions</p>
            </div>
            <Link href="/instructor/questions/new">
              <Button size="lg">
                + Create Question
              </Button>
            </Link>
          </div>

          {loading ? (
            <div className="text-center py-12">
              <p className="text-gray-600">Loading questions...</p>
            </div>
          ) : questions.length === 0 ? (
            <Card>
              <CardContent className="text-center py-12">
                <p className="text-gray-600 mb-4">You haven&apos;t created any questions yet.</p>
                <Link href="/instructor/questions/new">
                  <Button>Create Your First Question</Button>
                </Link>
              </CardContent>
            </Card>
          ) : (
            <Card>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Question</TableHead>
                    <TableHead>Points</TableHead>
                    <TableHead>Options</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {questions.map((question) => (
                    <TableRow key={question.id}>
                      <TableCell className="font-medium max-w-md">
                        {question.questionText.substring(0, 100)}
                        {question.questionText.length > 100 && '...'}
                      </TableCell>
                      <TableCell>{question.points}</TableCell>
                      <TableCell>{question.optionCount}</TableCell>
                      <TableCell>
                        <div className="flex gap-2">
                          <Link href={`/instructor/questions/${question.id}`}>
                            <Button size="sm" variant="outline">
                              View
                            </Button>
                          </Link>
                          <Link href={`/instructor/questions/${question.id}/edit`}>
                            <Button size="sm" variant="outline">
                              Edit
                            </Button>
                          </Link>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleDelete(question.id)}
                            className="text-red-600 hover:bg-red-50"
                          >
                            Delete
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>

              {totalPages > 1 && (
                <div className="flex justify-center gap-2 p-4 border-t">
                  <Button
                    variant="outline"
                    onClick={() => setPage(p => Math.max(1, p - 1))}
                    disabled={page === 1}
                  >
                    Previous
                  </Button>
                  <span className="flex items-center px-4 text-sm text-gray-600">
                    Page {page} of {totalPages}
                  </span>
                  <Button
                    variant="outline"
                    onClick={() => setPage(p => Math.min(totalPages, p + 1))}
                    disabled={page === totalPages}
                  >
                    Next
                  </Button>
                </div>
              )}
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}

