import { NextRequest, NextResponse } from 'next/server';
import { AuthService } from '@/lib/services/auth-service';
import { QuizService } from '@/lib/services/quiz-service';

export async function POST(request: NextRequest) {
  try {
    // Get token and verify authentication
    const token = request.cookies.get('auth_token')?.value;
    if (!token) {
      return NextResponse.json(
        { success: false, message: 'Not authenticated' },
        { status: 401 }
      );
    }

    const decoded = await AuthService.verifyToken(token);

    // Parse request body
    const body = await request.json();
    const { questionId, selectedOptionId, timeTakenSeconds } = body;

    if (!questionId || !selectedOptionId) {
      return NextResponse.json(
        {
          success: false,
          message: 'Question ID and selected option ID are required',
        },
        { status: 400 }
      );
    }

    // Submit answer
    const result = await QuizService.submitAnswer(decoded.userId, {
      questionId,
      selectedOptionId,
      timeTakenSeconds: timeTakenSeconds || 0,
    });

    return NextResponse.json(
      {
        success: true,
        ...result,
      },
      { status: 200 }
    );
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : 'Failed to submit answer';
    
    return NextResponse.json(
      {
        success: false,
        message: errorMessage,
      },
      { status: 400 }
    );
  }
}

