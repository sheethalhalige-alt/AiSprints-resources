import { NextRequest, NextResponse } from 'next/server';
import { AuthService } from '@/lib/services/auth-service';
import { QuizService } from '@/lib/services/quiz-service';

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    
    // Get token and verify authentication
    const token = request.cookies.get('auth_token')?.value;
    if (!token) {
      return NextResponse.json(
        { success: false, message: 'Not authenticated' },
        { status: 401 }
      );
    }

    const decoded = await AuthService.verifyToken(token);

    // Get attempt detail
    const attempt = await QuizService.getAttemptDetail(id, decoded.userId);

    return NextResponse.json(
      {
        success: true,
        attempt,
      },
      { status: 200 }
    );
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : 'Failed to get attempt';
    const status = errorMessage.includes('not found') ? 404 : 500;
    
    return NextResponse.json(
      {
        success: false,
        message: errorMessage,
      },
      { status }
    );
  }
}

