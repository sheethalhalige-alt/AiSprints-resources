import { NextRequest, NextResponse } from 'next/server';
import { AuthService } from '@/lib/services/auth-service';
import { QuestionService } from '@/lib/services/question-service';

export async function GET(request: NextRequest) {
  try {
    // Get token and verify authentication
    const token = request.cookies.get('auth_token')?.value;
    if (!token) {
      return NextResponse.json(
        { success: false, message: 'Not authenticated' },
        { status: 401 }
      );
    }

    const decoded = await AuthService.verifyToken(token);

    // Get query parameters
    const searchParams = request.nextUrl.searchParams;
    const excludeAttempted = searchParams.get('excludeAttempted') === 'true';

    // Get random question
    const question = await QuestionService.getRandomQuestion(
      decoded.userId,
      excludeAttempted
    );

    if (!question) {
      return NextResponse.json(
        {
          success: false,
          message: 'No questions available',
        },
        { status: 404 }
      );
    }

    return NextResponse.json(
      {
        success: true,
        question,
      },
      { status: 200 }
    );
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : 'Failed to get question';
    
    return NextResponse.json(
      {
        success: false,
        message: errorMessage,
      },
      { status: 500 }
    );
  }
}

