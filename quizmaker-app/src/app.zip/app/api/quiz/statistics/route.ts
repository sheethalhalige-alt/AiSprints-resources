import { NextRequest, NextResponse } from 'next/server';
import { AuthService } from '@/lib/services/auth-service';
import { QuizService } from '@/lib/services/quiz-service';

export async function GET(request: NextRequest) {
  try {
    // Get token and verify authentication
    const token = request.cookies.get('auth_token')?.value;
    if (!token) {
      return NextResponse.json(
        { success: false, message: 'Not authenticated' },
        { status: 401 }
      );
    }

    const decoded = await AuthService.verifyToken(token);

    // Get overall statistics
    const statistics = await QuizService.getStudentStatistics(decoded.userId);

    // Get category performance
    const categoryPerformance = await QuizService.getStudentPerformanceByCategory(decoded.userId);

    return NextResponse.json(
      {
        success: true,
        statistics,
        categoryPerformance,
      },
      { status: 200 }
    );
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : 'Failed to get statistics';
    
    return NextResponse.json(
      {
        success: false,
        message: errorMessage,
      },
      { status: 500 }
    );
  }
}

