import { NextRequest, NextResponse } from 'next/server';
import { AuthService } from '@/lib/services/auth-service';
import { QuestionService } from '@/lib/services/question-service';

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    
    // Get token and verify authentication
    const token = request.cookies.get('auth_token')?.value;
    if (!token) {
      return NextResponse.json(
        { success: false, message: 'Not authenticated' },
        { status: 401 }
      );
    }

    const decoded = await AuthService.verifyToken(token);

    // Get question (include correct answer only for instructors)
    const question = await QuestionService.getQuestionById(
      id,
      decoded.role === 'instructor'
    );

    if (!question) {
      return NextResponse.json(
        { success: false, message: 'Question not found' },
        { status: 404 }
      );
    }

    // If instructor, check ownership for edit permissions
    const canEdit = decoded.role === 'instructor' && question.instructorId === decoded.userId;

    return NextResponse.json(
      {
        success: true,
        question: {
          ...question,
          canEdit,
        },
      },
      { status: 200 }
    );
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : 'Failed to get question';
    
    return NextResponse.json(
      {
        success: false,
        message: errorMessage,
      },
      { status: 500 }
    );
  }
}

export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    
    // Get token and verify authentication
    const token = request.cookies.get('auth_token')?.value;
    if (!token) {
      return NextResponse.json(
        { success: false, message: 'Not authenticated' },
        { status: 401 }
      );
    }

    const decoded = await AuthService.verifyToken(token);

    // Check if user is instructor
    if (decoded.role !== 'instructor') {
      return NextResponse.json(
        { success: false, message: 'Instructor access required' },
        { status: 403 }
      );
    }

    // Parse request body
    const body = await request.json();

    // Update question
    await QuestionService.updateQuestion(id, decoded.userId, body);

    return NextResponse.json(
      {
        success: true,
        message: 'Question updated successfully',
      },
      { status: 200 }
    );
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : 'Failed to update question';
    const status = errorMessage.includes('not found') ? 404 :
                  errorMessage.includes('only edit your own') ? 403 : 400;
    
    return NextResponse.json(
      {
        success: false,
        message: errorMessage,
      },
      { status }
    );
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    
    // Get token and verify authentication
    const token = request.cookies.get('auth_token')?.value;
    if (!token) {
      return NextResponse.json(
        { success: false, message: 'Not authenticated' },
        { status: 401 }
      );
    }

    const decoded = await AuthService.verifyToken(token);

    // Check if user is instructor
    if (decoded.role !== 'instructor') {
      return NextResponse.json(
        { success: false, message: 'Instructor access required' },
        { status: 403 }
      );
    }

    // Get force parameter
    const searchParams = request.nextUrl.searchParams;
    const force = searchParams.get('force') === 'true';

    // Delete question
    await QuestionService.deleteQuestion(id, decoded.userId, force);

    return NextResponse.json(
      {
        success: true,
        message: 'Question deleted successfully',
      },
      { status: 200 }
    );
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : 'Failed to delete question';
    const status = errorMessage.includes('not found') ? 404 :
                  errorMessage.includes('only delete your own') ? 403 :
                  errorMessage.includes('has') && errorMessage.includes('attempts') ? 409 : 400;
    
    return NextResponse.json(
      {
        success: false,
        message: errorMessage,
      },
      { status }
    );
  }
}

