import { NextRequest, NextResponse } from 'next/server';
import { AuthService } from '@/lib/services/auth-service';
import { QuestionService } from '@/lib/services/question-service';

export async function POST(request: NextRequest) {
  try {
    // Get token and verify authentication
    const token = request.cookies.get('auth_token')?.value;
    if (!token) {
      return NextResponse.json(
        { success: false, message: 'Not authenticated' },
        { status: 401 }
      );
    }

    const decoded = await AuthService.verifyToken(token);

    // Check if user is instructor
    if (decoded.role !== 'instructor') {
      return NextResponse.json(
        { success: false, message: 'Instructor access required' },
        { status: 403 }
      );
    }

    // Parse request body
    const body = await request.json();

    // Create question
    const result = await QuestionService.createQuestion(decoded.userId, body);

    return NextResponse.json(
      {
        success: true,
        message: 'Question created successfully',
        questionId: result.questionId,
      },
      { status: 201 }
    );
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : 'Failed to create question';
    
    return NextResponse.json(
      {
        success: false,
        message: errorMessage,
      },
      { status: 400 }
    );
  }
}

