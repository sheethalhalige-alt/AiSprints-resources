'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';

interface Statistics {
  totalAttempts: number;
  correctAttempts: number;
  totalScore: number;
  averageScore: number;
  successRate: number;
}

interface CategoryPerformance {
  category: string;
  attempts: number;
  correct: number;
  successRate: number;
  averageScore: number;
}

export default function StudentStatisticsPage() {
  const [statistics, setStatistics] = useState<Statistics | null>(null);
  const [categoryPerformance, setCategoryPerformance] = useState<CategoryPerformance[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchStatistics();
  }, []);

  const fetchStatistics = async () => {
    try {
      const response = await fetch('/api/quiz/statistics');
      const data = await response.json();

      if (data.success) {
        setStatistics(data.statistics);
        setCategoryPerformance(data.categoryPerformance);
      }
    } catch (error) {
      console.error('Failed to fetch statistics:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <nav className="bg-white shadow-sm border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex justify-between items-center">
            <h1 className="text-2xl font-bold text-gray-900">My Statistics</h1>
            <Link href="/student/quiz">
              <Button variant="outline">Back to Quiz</Button>
            </Link>
          </div>
        </div>
      </nav>

      <div className="container mx-auto px-4 py-8">
        {loading ? (
          <div className="text-center py-12">
            <p className="text-gray-600">Loading statistics...</p>
          </div>
        ) : !statistics ? (
          <Card>
            <CardContent className="text-center py-12">
              <p className="text-gray-600">Failed to load statistics.</p>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <Card>
                <CardHeader>
                  <CardTitle className="text-sm font-medium text-gray-600">
                    Total Attempts
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-3xl font-bold">{statistics.totalAttempts}</p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-sm font-medium text-gray-600">
                    Correct Answers
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-3xl font-bold text-green-600">
                    {statistics.correctAttempts}
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-sm font-medium text-gray-600">
                    Success Rate
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-3xl font-bold text-blue-600">
                    {statistics.successRate.toFixed(1)}%
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-sm font-medium text-gray-600">
                    Total Score
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-3xl font-bold text-purple-600">
                    {statistics.totalScore}
                  </p>
                </CardContent>
              </Card>
            </div>

            {categoryPerformance.length > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle>Performance by Category</CardTitle>
                  <CardDescription>
                    Your success rate across different categories
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {categoryPerformance.map((cat) => (
                      <div key={cat.category} className="border-b pb-4 last:border-b-0">
                        <div className="flex justify-between items-center mb-2">
                          <h4 className="font-semibold text-gray-900">{cat.category}</h4>
                          <span className="text-sm text-gray-600">
                            {cat.attempts} attempt{cat.attempts !== 1 ? 's' : ''}
                          </span>
                        </div>
                        <div className="flex items-center gap-4">
                          <div className="flex-1">
                            <div className="w-full bg-gray-200 rounded-full h-2.5">
                              <div
                                className="bg-blue-600 h-2.5 rounded-full"
                                style={{ width: `${cat.successRate}%` }}
                              ></div>
                            </div>
                          </div>
                          <span className="text-sm font-semibold text-gray-900 w-16 text-right">
                            {cat.successRate.toFixed(1)}%
                          </span>
                        </div>
                        <div className="mt-1 text-sm text-gray-600">
                          {cat.correct} correct • Avg score: {cat.averageScore.toFixed(2)}
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}

            {statistics.totalAttempts === 0 && (
              <Card>
                <CardContent className="text-center py-12">
                  <p className="text-gray-600 mb-4">
                    You haven&apos;t attempted any questions yet.
                  </p>
                  <Link href="/student/quiz">
                    <Button>Start Taking Quizzes</Button>
                  </Link>
                </CardContent>
              </Card>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

