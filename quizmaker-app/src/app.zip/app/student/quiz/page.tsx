'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';

interface Question {
  id: string;
  questionText: string;
  points: number;
  options: Array<{
    id: string;
    text: string;
    order: number;
  }>;
}

export default function StudentQuizPage() {
  const router = useRouter();
  const [user, setUser] = useState<any>(null);
  const [question, setQuestion] = useState<Question | null>(null);
  const [selectedOption, setSelectedOption] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [result, setResult] = useState<any>(null);
  const [startTime, setStartTime] = useState<number>(Date.now());

  useEffect(() => {
    fetchUser();
    loadRandomQuestion();
  }, []);

  const fetchUser = async () => {
    try {
      const response = await fetch('/api/auth/me');
      const data = await response.json();
      if (data.success) {
        setUser(data.user);
      }
    } catch (error) {
      console.error('Failed to fetch user:', error);
    }
  };

  const loadRandomQuestion = async () => {
    setLoading(true);
    setSubmitted(false);
    setResult(null);
    setSelectedOption(null);
    setStartTime(Date.now());

    try {
      const response = await fetch('/api/quiz/random');
      const data = await response.json();

      if (data.success) {
        setQuestion(data.question);
      } else {
        alert(data.message || 'No questions available');
      }
    } catch (error) {
      alert('Failed to load question');
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async () => {
    if (!selectedOption || !question) return;

    const timeTaken = Math.floor((Date.now() - startTime) / 1000);
    setLoading(true);

    try {
      const response = await fetch('/api/quiz/submit', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          questionId: question.id,
          selectedOptionId: selectedOption,
          timeTakenSeconds: timeTaken,
        }),
      });

      const data = await response.json();

      if (data.success) {
        setResult(data);
        setSubmitted(true);
      } else {
        alert(data.message || 'Failed to submit answer');
      }
    } catch (error) {
      alert('Failed to submit answer');
    } finally {
      setLoading(false);
    }
  };

  const handleLogout = async () => {
    await fetch('/api/auth/logout', { method: 'POST' });
    router.push('/login');
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <nav className="bg-white shadow-sm border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex justify-between items-center">
            <h1 className="text-2xl font-bold text-gray-900">QuizMaker - Student</h1>
            <div className="flex items-center gap-4">
              <Link href="/student/attempts">
                <Button variant="outline">My Attempts</Button>
              </Link>
              <Link href="/student/statistics">
                <Button variant="outline">Statistics</Button>
              </Link>
              <span className="text-sm text-gray-600">
                {user?.name}
              </span>
              <Button variant="outline" onClick={handleLogout}>
                Logout
              </Button>
            </div>
          </div>
        </div>
      </nav>

      <div className="container mx-auto px-4 py-8">
        <div className="max-w-3xl mx-auto">
          {loading && !question && (
            <Card>
              <CardContent className="text-center py-12">
                <p className="text-gray-600">Loading question...</p>
              </CardContent>
            </Card>
          )}

          {!loading && !question && (
            <Card>
              <CardContent className="text-center py-12">
                <p className="text-gray-600 mb-4">No questions available at the moment.</p>
                <Button onClick={loadRandomQuestion}>Try Again</Button>
              </CardContent>
            </Card>
          )}

          {question && (
            <Card>
              <CardHeader>
                <div className="flex justify-between items-start mb-2">
                  <CardTitle className="text-xl">Question</CardTitle>
                  <Badge variant="outline" className="bg-indigo-100 text-indigo-800 border-indigo-200">
                    {question.points} point{question.points > 1 ? 's' : ''}
                  </Badge>
                </div>
                <CardDescription className="text-lg text-gray-900 mt-4">
                  {question.questionText}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3 mb-6">
                  {question.options.map((option, index) => (
                    <label
                      key={option.id}
                      className={`block p-4 border-2 rounded-lg cursor-pointer transition-all ${
                        selectedOption === option.id
                          ? 'border-blue-500 bg-blue-50'
                          : 'border-gray-200 hover:border-gray-300'
                      } ${submitted ? 'cursor-not-allowed' : ''} ${
                        submitted && result?.correctOptionId === option.id
                          ? 'border-green-500 bg-green-50'
                          : submitted && selectedOption === option.id && !result?.isCorrect
                          ? 'border-red-500 bg-red-50'
                          : ''
                      }`}
                    >
                      <input
                        type="radio"
                        name="answer"
                        value={option.id}
                        checked={selectedOption === option.id}
                        onChange={(e) => !submitted && setSelectedOption(e.target.value)}
                        disabled={submitted}
                        className="sr-only"
                      />
                      <div className="flex items-center">
                        <span className="flex-shrink-0 w-6 h-6 rounded-full border-2 border-gray-300 flex items-center justify-center mr-3">
                          <span className="w-3 h-3 rounded-full bg-blue-500" style={{ display: selectedOption === option.id ? 'block' : 'none' }}></span>
                        </span>
                        <span className="text-gray-900">{option.text}</span>
                        {submitted && result?.correctOptionId === option.id && (
                          <span className="ml-auto text-green-600 font-semibold">✓ Correct</span>
                        )}
                        {submitted && selectedOption === option.id && !result?.isCorrect && (
                          <span className="ml-auto text-red-600 font-semibold">✗ Incorrect</span>
                        )}
                      </div>
                    </label>
                  ))}
                </div>

                {submitted && result && (
                  <div className={`p-4 rounded-lg mb-4 ${result.isCorrect ? 'bg-green-50' : 'bg-red-50'}`}>
                    <p className={`font-semibold mb-1 ${result.isCorrect ? 'text-green-800' : 'text-red-800'}`}>
                      {result.isCorrect ? 'Correct!' : 'Incorrect'}
                    </p>
                    <p className={result.isCorrect ? 'text-green-700' : 'text-red-700'}>
                      You earned {result.score} out of {question.points} points.
                    </p>
                  </div>
                )}

                <div className="flex gap-3">
                  {!submitted ? (
                    <Button
                      onClick={handleSubmit}
                      disabled={!selectedOption || loading}
                      className="flex-1"
                    >
                      {loading ? 'Submitting...' : 'Submit Answer'}
                    </Button>
                  ) : (
                    <Button onClick={loadRandomQuestion} className="flex-1">
                      Next Question
                    </Button>
                  )}
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}

