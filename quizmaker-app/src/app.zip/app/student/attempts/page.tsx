'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';

interface Attempt {
  id: string;
  questionId: string;
  questionText: string;
  isCorrect: boolean;
  score: number;
  maxPoints: number;
  timeTakenSeconds: number;
  attemptDate: string;
}

export default function StudentAttemptsPage() {
  const router = useRouter();
  const [attempts, setAttempts] = useState<Attempt[]>([]);
  const [loading, setLoading] = useState(true);
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);

  useEffect(() => {
    fetchAttempts();
  }, [page]);

  const fetchAttempts = async () => {
    try {
      const response = await fetch(`/api/quiz/attempts?page=${page}&limit=20`);
      const data = await response.json();

      if (data.success) {
        setAttempts(data.attempts);
        setTotalPages(data.totalPages);
      }
    } catch (error) {
      console.error('Failed to fetch attempts:', error);
    } finally {
      setLoading(false);
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return mins > 0 ? `${mins}m ${secs}s` : `${secs}s`;
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <nav className="bg-white shadow-sm border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex justify-between items-center">
            <h1 className="text-2xl font-bold text-gray-900">My Attempts</h1>
            <div className="flex items-center gap-4">
              <Link href="/student/quiz">
                <Button variant="outline">Back to Quiz</Button>
              </Link>
            </div>
          </div>
        </div>
      </nav>

      <div className="container mx-auto px-4 py-8">
        {loading ? (
          <div className="text-center py-12">
            <p className="text-gray-600">Loading attempts...</p>
          </div>
        ) : attempts.length === 0 ? (
          <Card>
            <CardContent className="text-center py-12">
              <p className="text-gray-600 mb-4">You haven&apos;t attempted any questions yet.</p>
              <Link href="/student/quiz">
                <Button>Start Taking Quizzes</Button>
              </Link>
            </CardContent>
          </Card>
        ) : (
          <Card>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Question</TableHead>
                  <TableHead>Result</TableHead>
                  <TableHead>Score</TableHead>
                  <TableHead>Time</TableHead>
                  <TableHead>Date</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {attempts.map((attempt) => (
                  <TableRow key={attempt.id}>
                    <TableCell className="font-medium max-w-md">
                      {attempt.questionText.substring(0, 60)}
                      {attempt.questionText.length > 60 && '...'}
                    </TableCell>
                    <TableCell>
                      {attempt.isCorrect ? (
                        <Badge className="bg-green-100 text-green-800">✓ Correct</Badge>
                      ) : (
                        <Badge className="bg-red-100 text-red-800">✗ Incorrect</Badge>
                      )}
                    </TableCell>
                    <TableCell>
                      {attempt.score}/{attempt.maxPoints}
                    </TableCell>
                    <TableCell>{formatTime(attempt.timeTakenSeconds)}</TableCell>
                    <TableCell className="text-sm text-gray-600">
                      {formatDate(attempt.attemptDate)}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>

            {totalPages > 1 && (
              <div className="flex justify-center gap-2 p-4 border-t">
                <Button
                  variant="outline"
                  onClick={() => setPage(p => Math.max(1, p - 1))}
                  disabled={page === 1}
                >
                  Previous
                </Button>
                <span className="flex items-center px-4 text-sm text-gray-600">
                  Page {page} of {totalPages}
                </span>
                <Button
                  variant="outline"
                  onClick={() => setPage(p => Math.min(totalPages, p + 1))}
                  disabled={page === totalPages}
                >
                  Next
                </Button>
              </div>
            )}
          </Card>
        )}
      </div>
    </div>
  );
}

